class PandasMySQLError(Exception):
    pass

class PandasMySQLError_dev(Exception):
    pass